## dotfiles

Hammerspoon

* position - dynamically controls screen position

* timer - A menu bar timer activated through url event request

* focus - quick focus/launch to specific application